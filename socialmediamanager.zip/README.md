# Social Media Manager plugin for Craft CMS 3.x

Manage user's social media accounts. Post and get statuses and see stats

![Screenshot](resources/img/plugin-logo.png)

## Requirements

This plugin requires Craft CMS 3.0.0-beta.23 or later.

## Installation

To install the plugin, follow these instructions.

1. Open your terminal and go to your Craft project:

        cd /path/to/project

2. Then tell Composer to load the plugin:

        composer require /social-media-manager

3. In the Control Panel, go to Settings → Plugins and click the “Install” button for Social Media Manager.

## Social Media Manager Overview

-Insert text here-

## Configuring Social Media Manager

-Insert text here-

## Using Social Media Manager

-Insert text here-

## Social Media Manager Roadmap

Some things to do, and ideas for potential features:

* Release it

Brought to you by [Nightfall Studios](https://www.nightfallstudios.com.au/)
